// dos Web Components 
import './boton-app';
import './tarjeta-producto';

import type {
  Producto,
} from './tipos';

// Datos que utilizamos para construir el catálogo
const productos: Producto[] = [
  {
    id: 'P-001',
    nombre: 'Tenis para correr Vento',
    precio: 1299,
    categoria: 'calzado',
    imagen: '/img/producto-01.jpg',
    existencia: 8,
  },
  {
    id: 'P-002',
    nombre: 'Tenis de entrenamiento Cross',
    precio: 1549,
    categoria: 'calzado',
    imagen: '/img/producto-02.jpg',
    existencia: 25,
  },
  {
    id: 'P-003',
    nombre: 'Tenis casuales Urbano',
    precio: 989,
    categoria: 'calzado',
    imagen: '/img/producto-03.jpg',
    existencia: 8,
  },
  {
    id: 'P-004',
    nombre: 'Sandalias de recuperación',
    precio: 449,
    categoria: 'calzado',
    imagen: '/img/producto-04.jpg',
    existencia: 25,
  },
  {
    id: 'P-005',
    nombre: 'Playera deportiva seca',
    precio: 399,
    categoria: 'ropa',
    imagen: '/img/producto-05.jpg',
    existencia: 3,
  },
  {
    id: 'P-006',
    nombre: 'Playera de algodón clásica',
    precio: 289,
    categoria: 'ropa',
    imagen: '/img/producto-06.jpg',
    existencia: 25,
  },
  {
    id: 'P-007',
    nombre: 'Sudadera con capucha',
    precio: 749,
    categoria: 'ropa',
    imagen: '/img/producto-07.jpg',
    existencia: 8,
  },
  {
    id: 'P-008',
    nombre: 'Short de entrenamiento',
    precio: 359,
    categoria: 'ropa',
    imagen: '/img/producto-08.jpg',
    existencia: 12,
  },
  {
    id: 'P-009',
    nombre: 'Licra de compresión',
    precio: 529,
    categoria: 'ropa',
    imagen: '/img/producto-09.jpg',
    existencia: 0,
  },
  {
    id: 'P-010',
    nombre: 'Pantalón deportivo',
    precio: 649,
    categoria: 'ropa',
    imagen: '/img/producto-10.jpg',
    existencia: 5,
  },
  {
    id: 'P-011',
    nombre: 'Chamarra rompeviento',
    precio: 899,
    categoria: 'ropa',
    imagen: '/img/producto-11.jpg',
    existencia: 0,
  },
  {
    id: 'P-012',
    nombre: 'Calcetas deportivas (3 pares)',
    precio: 179,
    categoria: 'ropa',
    imagen: '/img/producto-12.jpg',
    existencia: 25,
  },
];

// Buscamos los elementos principales del HTML
const rejilla =
  document.querySelector<HTMLElement>(
    '#rejilla',
  );

const cuenta =
  document.querySelector<HTMLElement>(
    '#cuenta',
  );

const vaciar =
  document.querySelector<HTMLElement>(
    '#vaciar',
  );

// Si falta alguno, detenemos el programa para evitar otros errores
if (
  !rejilla ||
  !cuenta ||
  !vaciar
) {
  throw new Error(
    'No se encontraron los elementos principales de la página',
  );
}

// Creamos una tarjeta por cada producto
for (const producto of productos) {

  const tarjeta =
    document.createElement(
      'tarjeta-producto',
    );

  // Pasamos los datos del producto mediante atributos
  tarjeta.setAttribute(
    'producto-id',
    producto.id,
  );

  tarjeta.setAttribute(
    'nombre',
    producto.nombre,
  );

  tarjeta.setAttribute(
    'precio',
    String(producto.precio),
  );

  tarjeta.setAttribute(
    'imagen',
    producto.imagen,
  );

  tarjeta.setAttribute(
    'existencia',
    String(producto.existencia),
  );

  // Finalmente agregamos la tarjeta al catálogo
  rejilla.appendChild(
    tarjeta,
  );
}

// Cantidad de productos agregados al carrito
let cantidad = 0;

// Escuchamos el evento una sola vez desde el contenedor
// No necesitamos un listener diferente para cada tarjeta
rejilla.addEventListener(
  'agregar',
  (evento) => {

    cantidad++;

    cuenta.textContent =
      String(cantidad);

    // Esto nos deja ver qué producto generó el evento
    console.log(
      'Producto agregado:',
      evento.detail,
    );
  },
);

// El botón Vaciar vuelve el contador a cero
vaciar.addEventListener(
  'click',
  () => {

    cantidad = 0;

    cuenta.textContent =
      String(cantidad);
  },
);