# Práctica 11 - Componentes con TypeScript puro

En esta práctica hicimos un catálogo usando TypeScript puro y Web Components. La idea fue crear componentes que se pudieran volver a utilizar sin tener que repetir el mismo código para cada producto.

Se hicieron principalmente dos componentes: un botón y una tarjeta de producto.

## Ejercicio 1 - Botón

Para el primer ejercicio hice el componente `<boton-app>`.

El botón recibe su variante por medio de un atributo, por ejemplo:

```html
<boton-app variante="primario">
  Primario
</boton-app>